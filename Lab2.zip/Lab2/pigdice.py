import turtle
import random
from score import Keeper

player_score = Keeper()
colors = ['green', 'red']

SIDE = 100
sc = turtle.Screen()
sc.setup(800, 600)
sc.register_shape('hold_turtle_button', ((30, 30), (75, 30), (75, 170), (30, 170)))

player_score_track = turtle.Turtle()


hold_turtle = turtle.Turtle()
hold_turtle.up()
hold_turtle.hideturtle()
hold_turtle.right(90)
hold_turtle.forward(100)
hold_turtle.left(90)
hold_turtle.color('blue')
hold_turtle.left(90)
hold_turtle.forward(100)
hold_turtle.right(180)
hold_turtle.forward(100)
hold_turtle.down()
style_hold = ('Arial', 15, 'italic')
hold_turtle.write("Click on blue box to hold", font=style_hold, align='center')
hold_turtle.up()
hold_turtle.left(180)
hold_turtle.forward(100)
hold_turtle.right(90)
hold_turtle.shape('hold_turtle_button')

drawing_turtle = turtle.Turtle()
drawing_turtle.up()
drawing_turtle.back(50)
drawing_turtle.speed(0)


def update_score() -> None:
    player_score_track.clear()
    style = ('Arial', 20, 'bold')
    player_score_track.speed(0)
    player_score_track.hideturtle()
    player_score_track.up()
    player_score_track.left(90)
    player_score_track.forward(250)
    player_score_track.right(90)
    player_score_track.back(300)
    player_score_track.color(colors[player_score.player])
    player_1_text = 'Player 1'
    if player_score.player == 0:
        player_1_text = player_1_text + ' *'
    player_score_track.write(player_1_text, font=style, align='center')
    player_score_track.right(90)
    player_score_track.forward(50)
    player_score_track.left(90)
    player_score_track.write(player_score.score[0], font=style, align='center')
    player_score_track.right(90)
    player_score_track.backward(50)
    player_score_track.left(90)
    player_score_track.forward(600)
    player_score_track.color(colors[1 - player_score.player])
    player_2_text = 'Player 2'
    if player_score.player == 1:
        player_2_text = player_2_text + ' *'
    player_score_track.write(player_2_text, font=style, align='center')
    player_score_track.right(90)
    player_score_track.forward(50)
    player_score_track.left(90)
    player_score_track.write(player_score.score[1], font=style, align='center')
    player_score_track.right(90)
    player_score_track.backward(50)
    player_score_track.left(90)
    player_score_track.back(300)
    player_score_track.right(90)
    player_score_track.forward(250)
    player_score_track.left(90)


def draw_dot_at_center() -> None:
    drawing_turtle.forward(SIDE/2)
    drawing_turtle.left(90)
    drawing_turtle.forward(SIDE/2)
    drawing_turtle.dot(10)
    drawing_turtle.left(180)
    drawing_turtle.forward(SIDE/2)
    drawing_turtle.right(90)
    drawing_turtle.forward(SIDE/2)
    drawing_turtle.left(180)


def draw_two() -> None:
    drawing_turtle.back(SIDE/4)
    drawing_turtle.left(90)
    drawing_turtle.forward(SIDE/4)
    drawing_turtle.right(90)
    draw_dot_at_center()
    drawing_turtle.right(90)
    drawing_turtle.forward(SIDE/4)
    drawing_turtle.left(90)
    drawing_turtle.forward(SIDE/2)
    drawing_turtle.right(90)
    drawing_turtle.forward(SIDE/4)
    drawing_turtle.left(90)
    draw_dot_at_center()
    drawing_turtle.left(90)
    drawing_turtle.forward(SIDE/4)
    drawing_turtle.right(90)
    drawing_turtle.back(SIDE/4)


def draw_four() -> None:
    draw_two()
    drawing_turtle.forward(SIDE)
    drawing_turtle.left(90)
    draw_two()
    drawing_turtle.right(90)
    drawing_turtle.back(SIDE)


def draw_five() -> None:
    draw_four()
    draw_dot_at_center()


def draw_three() -> None:
    draw_dot_at_center()
    draw_two()


def draw_six() -> None:
    draw_four()
    drawing_turtle.left(90)
    drawing_turtle.forward(SIDE/4)
    drawing_turtle.right(90)
    draw_dot_at_center()
    drawing_turtle.right(90)
    drawing_turtle.forward(SIDE/2)
    drawing_turtle.left(90)
    draw_dot_at_center()
    drawing_turtle.left(90)
    drawing_turtle.forward(SIDE/4)
    drawing_turtle.right(90)


def draw_square() -> None:
    drawing_turtle.down()
    for i in range(0, 4):
        drawing_turtle.forward(SIDE)
        drawing_turtle.left(90)
    drawing_turtle.up()


def draw_dice(dice_digit) -> None:
    draw_square()
    if dice_digit == 2:
        draw_two()
    elif dice_digit == 3:
        draw_three()
    elif dice_digit == 4:
        draw_four()
    elif dice_digit == 5:
        draw_five()
    elif dice_digit == 6:
        draw_six()
    else:
        draw_dot_at_center()


def start_the_game(x, y) -> None:
    drawing_turtle.clear()
    drawing_turtle.up()
    random_integer = random.randint(1, 6)
    if random_integer == 1:
        player_score.points = 0
        player_score.switch_player()
        update_score()
    else:
        player_score.add_points(random_integer)
    draw_dice(random_integer)


sc = turtle.Screen()
sc.setup(800, 600)


def print_player_won(player_won) -> None:
    style = ('Arial', 20, 'bold')
    player_won_turtle = turtle.Turtle()
    player_won_turtle.up()
    player_won_turtle.hideturtle()
    player_won_turtle.speed(0)
    player_won_turtle.right(90)
    player_won_turtle.forward(250)
    player_won_turtle.left(90)
    player_won_turtle.write("Player " + str(player_won) + " won", font=style, align='center')


def print_hello(x, y) -> None:
    player_score.score[player_score.player] = player_score.score[player_score.player] + player_score.points
    if player_score.score[player_score.player] >= 10:
        update_score()
        print_player_won(player_score.player + 1)
    else:
        player_score.points = 0
        player_score.switch_player()
        update_score()


hold_turtle.showturtle()
hold_turtle.back(100)
if __name__ == '__main__':
    update_score()
    turtle.onscreenclick(start_the_game)
    hold_turtle.onclick(print_hello)
    turtle.mainloop()
    sc.mainloop()

